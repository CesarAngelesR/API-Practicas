package com.alura.foro.infra.security;

public record DatosJWTToken(String jwTtoken) {

}
