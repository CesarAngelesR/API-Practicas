package com.alura.foro.modelo.curso;


public enum Curso {
	
	Front_End,
	Back_End,
	MySQL,
	Soft_Skills;
	
}
