package com.alura.foro.modelo.topico;

public enum StatusTopico {
	
	NO_RESPONDIDO,
	NO_SOLUCIONADO,
	SOLUCIONADO,
	CERRADO;

}

