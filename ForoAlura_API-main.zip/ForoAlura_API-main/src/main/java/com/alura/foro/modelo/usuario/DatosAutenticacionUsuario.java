package com.alura.foro.modelo.usuario;

public record DatosAutenticacionUsuario(String email, String contrasena) {

}
