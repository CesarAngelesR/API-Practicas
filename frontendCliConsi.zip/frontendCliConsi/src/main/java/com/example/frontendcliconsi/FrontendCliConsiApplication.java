package com.example.frontendcliconsi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontendCliConsiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FrontendCliConsiApplication.class, args);
    }

}
