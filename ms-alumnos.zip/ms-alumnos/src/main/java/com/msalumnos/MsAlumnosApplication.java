package com.msalumnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsAlumnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAlumnosApplication.class, args);
	}

}
