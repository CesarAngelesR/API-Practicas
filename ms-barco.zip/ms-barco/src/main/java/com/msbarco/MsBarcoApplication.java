package com.msbarco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsBarcoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsBarcoApplication.class, args);
	}

}
