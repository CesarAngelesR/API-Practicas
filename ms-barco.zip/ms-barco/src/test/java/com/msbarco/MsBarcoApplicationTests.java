package com.msbarco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsBarcoApplicationTests {

	@Test
	void contextLoads() {
	}

}
